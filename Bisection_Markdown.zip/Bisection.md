## 1

```python
def bisection(f, a, b, eps=1e-9, max_iter=200):
    if a >= b or eps <= 0 or max_iter < 1:
        raise ValueError("Требуются a < b, eps > 0 и max_iter >= 1")

    fa, fb = f(a), f(b)
    journal = []

    if fa == 0:
        return a, journal, "f_zero"
    if fb == 0:
        return b, journal, "f_zero"
    if (fa < 0) == (fb < 0):
        raise ValueError(
            f"Нет смены знака на [{a}, {b}]: f(a)={fa}, f(b)={fb}"
        )

    for k in range(1, max_iter + 1):
        length = b - a
        c = a + length / 2
        fc = f(c)

        journal.append({
            "iter": k,
            "a": a,
            "b": b,
            "c": c,
            "f(c)": fc,
            "length": length,
        })

        if fc == 0:
            return c, journal, "f_zero"
        if length < eps or abs(fc) < eps:
            return c, journal, "ok"

        if (fa < 0) != (fc < 0):
            b = c
        else:
            a = c
            fa = fc

    return c, journal, "max_iter"
```

![График полинома на отрезке от 0 до 4](Graphs/polynomial.png)

![Журнал итераций для первого корня](Screenshots/01_journal_root_1.png)

![Журнал итераций для второго корня](Screenshots/02_journal_root_2.png)

![Журнал итераций для третьего корня](Screenshots/03_journal_root_3.png)

## 2

![Журнал итераций для k = 0.5](Screenshots/04_journal_k_0.5.png)

![График зависимости корня от k](Graphs/root_vs_k.png)

![График зависимости числа итераций от точности](Graphs/iterations_vs_eps.png)

![Итоговые таблицы для обеих задач](Screenshots/05_tables.png)
